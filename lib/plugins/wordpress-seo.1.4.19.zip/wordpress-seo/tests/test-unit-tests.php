<?php

class WPSEO_Test_Unit_Tests extends WPSEO_TestCase {
	function test_true_is_true() {
		$this->assertTrue( true ); // Yay, your unit tests are running!
	}
}
